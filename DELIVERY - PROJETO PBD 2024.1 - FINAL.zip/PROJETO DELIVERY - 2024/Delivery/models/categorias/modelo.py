class Categoria:
    def __init__(self, name, id=None):
        self.id = id
        self.name = name