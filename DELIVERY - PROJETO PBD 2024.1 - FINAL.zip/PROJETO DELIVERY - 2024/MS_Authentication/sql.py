verificar_usuario_sql = "select * from Usuario where username=%s and password=%s"
verificar_username_sql = "select * from Usuario where username=%s"