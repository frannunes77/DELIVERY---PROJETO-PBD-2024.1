class SQLCategoria:

    todas_as_categorias = "select * from Categoria"
